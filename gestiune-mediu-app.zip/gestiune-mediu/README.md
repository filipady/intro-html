# 🌿 Gestiune Mediu — Platformă Declarații & Termene

Aplicație Next.js 14 completă pentru gestionarea documentelor de mediu, termenelor scadente și notificărilor automate prin email.

## 🚀 Funcționalități

- ✅ **Multi-user** cu roluri (Admin, Manager, User)
- 📅 **Calendar interactiv** cu toate termenele vizualizate lunar
- 📄 **Gestiune declarații** — AFM, autorizații, avize, acorduri
- ⏰ **Termene scadente** cu prioritizare (Critică/Ridicată/Medie/Scăzută)
- 📧 **Notificări email automate** — cu 3 zile, 1 zi și în ziua scadenței
- 📊 **Dashboard** cu statistici și vizualizare rapidă
- 📈 **Rapoarte** cu calendar legislativ Romania mediu
- 🔐 **Autentificare securizată** cu NextAuth + JWT

## 📋 Cerințe

- Node.js 18+
- PostgreSQL (local, Supabase, Neon, sau Railway)
- Cont Gmail cu App Password (pentru notificări email)

## 🔧 Instalare

### 1. Clonează/dezarhivează proiectul
```bash
cd gestiune-mediu
npm install
```

### 2. Configurează variabilele de mediu
```bash
cp .env.example .env
```

Editează `.env`:
```env
# PostgreSQL - alege una:
DATABASE_URL="postgresql://postgres:parola@localhost:5432/gestiune_mediu"
# SAU Supabase: DATABASE_URL="postgresql://postgres:pass@db.xxx.supabase.co:5432/postgres"

# NextAuth
NEXTAUTH_SECRET="genereaza-cu-openssl-rand-base64-32"
NEXTAUTH_URL="http://localhost:3000"

# Gmail App Password (Settings → Security → 2FA → App Passwords)
SMTP_HOST="smtp.gmail.com"
SMTP_PORT=587
SMTP_USER="adresa-ta@gmail.com"
SMTP_PASS="parola-aplicatie-16-caractere"
EMAIL_FROM="Gestiune Mediu <adresa-ta@gmail.com>"
APP_URL="http://localhost:3000"
```

### 3. Inițializează baza de date
```bash
# Creează tabelele
npm run db:push

# Populează cu date demo
npm run db:seed
```

### 4. Pornește aplicația
```bash
npm run dev
# Deschide http://localhost:3000
```

## 👤 Conturi Demo

| Rol | Email | Parolă |
|-----|-------|--------|
| Admin | `admin@gestiunemediu.ro` | `Admin2024!` |
| User | `consultant@gestiunemediu.ro` | `User2024!` |

## 📧 Configurare Notificări Email

### Gmail App Password:
1. Contul Google → **Securitate** → **Verificare în 2 pași** (activează)
2. Caută **"Parole pentru aplicații"**
3. Alege "Altă aplicație" → Numește-o "Gestiune Mediu"
4. Copiază parola de 16 caractere în `SMTP_PASS`

### Testare notificări manual:
```bash
curl -X GET http://localhost:3000/api/notificari \
  -H "Authorization: Bearer secret-cron-key"
```

## 🚀 Deploy pe Vercel

```bash
npm install -g vercel
vercel --prod
```

Adaugă variabilele din `.env` în Vercel Dashboard → Settings → Environment Variables.

**Cron job** (notificări zilnice la 08:00): configurat automat prin `vercel.json`.

## 📁 Structura Proiect

```
src/
├── app/
│   ├── (auth)/          # Login, Register
│   ├── (dashboard)/     # Dashboard, Calendar, Declarații, Termene, Rapoarte, Setări
│   └── api/             # REST API routes
├── components/          # Sidebar, Providers
├── lib/                 # Prisma, Auth, Email, Notificări
└── types/               # TypeScript types
prisma/
├── schema.prisma        # Schema baza de date
└── seed.js              # Date demo
```

## 🗄️ Modele baza de date

- **User** — utilizatori cu roluri și preferințe
- **Declaratie** — documente (AFM, autorizații, avize etc.)
- **Termen** — termene scadente cu prioritate și status
- **Raport** — rapoarte periodice
- **NotificareLog** — jurnal emailuri trimise

## ⚖️ Termene Legale România (mediu)

- **25 ale fiecărei luni** — plată taxă fond mediu
- **25 aprilie** — declarație anuală AFM
- **Lunar** — raportări deșeuri
- **Trimestrial** — raportări APM
- **La expirare** — reînnoire autorizații de mediu

---
*Dezvoltat cu Next.js 14 + PostgreSQL + Prisma + NextAuth + Nodemailer*
