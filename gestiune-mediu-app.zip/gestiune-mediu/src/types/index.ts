import type { User, Declaratie, Termen, Raport } from '@prisma/client'

export type { User, Declaratie, Termen, Raport }

export type DeclaratieWithTermene = Declaratie & {
  termene: Termen[]
  user: Pick<User, 'name' | 'email' | 'firma'>
}

export type TermenWithDeclaratie = Termen & {
  declaratie: Pick<Declaratie, 'titlu' | 'tip'> | null
  user: Pick<User, 'name' | 'email'>
}

// NextAuth session extension
declare module 'next-auth' {
  interface Session {
    user: {
      id: string
      email: string
      name: string
      role: string
      firma: string
    }
  }
}
