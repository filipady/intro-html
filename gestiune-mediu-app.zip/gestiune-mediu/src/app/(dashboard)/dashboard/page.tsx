import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { prisma } from '@/lib/prisma'
import Link from 'next/link'
import { format, differenceInDays } from 'date-fns'
import { ro } from 'date-fns/locale'

function prioritateBadge(p: string) {
  const map: Record<string, string> = {
    CRITICA: 'bg-red-100 text-red-800',
    RIDICATA: 'bg-orange-100 text-orange-800',
    MEDIE: 'bg-yellow-100 text-yellow-800',
    SCAZUTA: 'bg-green-100 text-green-800',
  }
  return map[p] || 'bg-gray-100 text-gray-800'
}

function zileLabel(zile: number) {
  if (zile < 0) return <span className="text-red-600 font-semibold">Depășit cu {Math.abs(zile)} zile</span>
  if (zile === 0) return <span className="text-red-600 font-semibold">Azi!</span>
  if (zile === 1) return <span className="text-orange-600 font-semibold">Mâine</span>
  return <span className="text-gray-600">Peste {zile} zile</span>
}

export default async function DashboardPage() {
  const session = await getServerSession(authOptions)
  const userId = session!.user.id
  const isAdmin = session!.user.role === 'ADMIN'

  const azi = new Date()

  // Stats
  const [totalDeclaratii, totalTermene, termeneActive, termeneDepasit, declaratiiExpirate] = await Promise.all([
    prisma.declaratie.count({ where: isAdmin ? {} : { userId } }),
    prisma.termen.count({ where: isAdmin ? { status: 'ACTIV' } : { userId, status: 'ACTIV' } }),
    prisma.termen.count({ where: isAdmin ? { status: 'ACTIV', dataScadenta: { gte: azi } } : { userId, status: 'ACTIV', dataScadenta: { gte: azi } } }),
    prisma.termen.count({ where: isAdmin ? { status: 'DEPASIT' } : { userId, status: 'DEPASIT' } }),
    prisma.declaratie.count({ where: isAdmin ? { status: 'EXPIRAT' } : { userId, status: 'EXPIRAT' } }),
  ])

  // Upcoming termene
  const termeneUrgente = await prisma.termen.findMany({
    where: {
      ...(isAdmin ? {} : { userId }),
      status: { in: ['ACTIV', 'DEPASIT'] },
    },
    orderBy: { dataScadenta: 'asc' },
    take: 8,
    include: {
      user: { select: { name: true } },
      declaratie: { select: { titlu: true } },
    },
  })

  // Recent declaratii
  const recentDeclaratii = await prisma.declaratie.findMany({
    where: isAdmin ? {} : { userId },
    orderBy: { updatedAt: 'desc' },
    take: 5,
    include: { user: { select: { name: true } } },
  })

  const stats = [
    { label: 'Declarații', value: totalDeclaratii, icon: '📄', color: 'bg-blue-50 text-blue-700', border: 'border-blue-200' },
    { label: 'Termene Active', value: termeneActive, icon: '✅', color: 'bg-green-50 text-green-700', border: 'border-green-200' },
    { label: 'Termene Depășite', value: termeneDepasit, icon: '⚠️', color: 'bg-red-50 text-red-700', border: 'border-red-200' },
    { label: 'Documente Expirate', value: declaratiiExpirate, icon: '📋', color: 'bg-orange-50 text-orange-700', border: 'border-orange-200' },
  ]

  const statusLabel: Record<string, string> = {
    IN_LUCRU: 'În lucru', DEPUS: 'Depus', APROBAT: 'Aprobat', RESPINS: 'Respins', EXPIRAT: 'Expirat'
  }
  const statusColor: Record<string, string> = {
    IN_LUCRU: 'bg-yellow-100 text-yellow-800', DEPUS: 'bg-blue-100 text-blue-800',
    APROBAT: 'bg-green-100 text-green-800', RESPINS: 'bg-red-100 text-red-800', EXPIRAT: 'bg-gray-100 text-gray-800'
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">
            Bună ziua, {session!.user.name?.split(' ')[0]}! 👋
          </h1>
          <p className="text-gray-500 mt-0.5">
            {format(azi, "EEEE, d MMMM yyyy", { locale: ro })}
          </p>
        </div>
        <div className="flex gap-3">
          <Link href="/termene/new" className="btn-primary">
            <span>⏰</span> Adaugă Termen
          </Link>
          <Link href="/declaratii/new" className="btn-secondary">
            <span>📄</span> Declarație Nouă
          </Link>
        </div>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-4 gap-4">
        {stats.map(s => (
          <div key={s.label} className={`card p-5 border ${s.border}`}>
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-500">{s.label}</p>
                <p className="text-3xl font-bold text-gray-900 mt-1">{s.value}</p>
              </div>
              <div className={`w-12 h-12 rounded-xl flex items-center justify-center text-2xl ${s.color}`}>
                {s.icon}
              </div>
            </div>
          </div>
        ))}
      </div>

      <div className="grid grid-cols-5 gap-6">
        {/* Termene urgente - 3/5 */}
        <div className="col-span-3 card">
          <div className="p-5 border-b border-gray-100 flex items-center justify-between">
            <h2 className="font-bold text-gray-900 flex items-center gap-2">
              <span>⏰</span> Termene Urgente
            </h2>
            <Link href="/termene" className="text-sm text-green-600 hover:underline font-medium">
              Vezi toate →
            </Link>
          </div>
          <div className="divide-y divide-gray-50">
            {termeneUrgente.length === 0 ? (
              <p className="p-6 text-center text-gray-400">✅ Nu sunt termene urgente</p>
            ) : (
              termeneUrgente.map(t => {
                const zile = differenceInDays(new Date(t.dataScadenta), azi)
                return (
                  <div key={t.id} className="p-4 flex items-center gap-4 hover:bg-gray-50 transition-colors">
                    <div className={`w-2 h-10 rounded-full flex-shrink-0 ${
                      zile < 0 ? 'bg-red-500' : zile <= 3 ? 'bg-orange-500' : zile <= 7 ? 'bg-yellow-500' : 'bg-green-500'
                    }`} />
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-semibold text-gray-900 truncate">{t.titlu}</p>
                      <p className="text-xs text-gray-500 mt-0.5">
                        {format(new Date(t.dataScadenta), 'd MMM yyyy', { locale: ro })}
                        {isAdmin && <span className="ml-2 text-gray-400">· {t.user.name}</span>}
                      </p>
                    </div>
                    <div className="flex items-center gap-2 flex-shrink-0">
                      <span className={`text-xs px-2 py-0.5 rounded-full font-medium ${prioritateBadge(t.prioritate)}`}>
                        {t.prioritate}
                      </span>
                      <span className="text-xs">{zileLabel(zile)}</span>
                    </div>
                  </div>
                )
              })
            )}
          </div>
        </div>

        {/* Recent declaratii - 2/5 */}
        <div className="col-span-2 card">
          <div className="p-5 border-b border-gray-100 flex items-center justify-between">
            <h2 className="font-bold text-gray-900 flex items-center gap-2">
              <span>📄</span> Declarații Recente
            </h2>
            <Link href="/declaratii" className="text-sm text-green-600 hover:underline font-medium">
              Toate →
            </Link>
          </div>
          <div className="divide-y divide-gray-50">
            {recentDeclaratii.length === 0 ? (
              <p className="p-6 text-center text-gray-400">Nicio declarație adăugată</p>
            ) : (
              recentDeclaratii.map(d => (
                <Link key={d.id} href={`/declaratii/${d.id}`} className="p-4 flex items-center gap-3 hover:bg-gray-50 transition-colors block">
                  <div className="text-xl">{
                    d.tip === 'AUTORIZATIE_MEDIU' ? '🔒' :
                    d.tip === 'DECLARATIE_AFM' ? '💰' :
                    d.tip === 'AVIZ_MEDIU' ? '📋' : '📄'
                  }</div>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium text-gray-900 truncate">{d.titlu}</p>
                    <p className="text-xs text-gray-500">{d.tip.replace(/_/g, ' ')}</p>
                  </div>
                  <span className={`text-xs px-2 py-0.5 rounded-full font-medium flex-shrink-0 ${statusColor[d.status]}`}>
                    {statusLabel[d.status]}
                  </span>
                </Link>
              ))
            )}
          </div>
          <div className="p-4 border-t border-gray-100">
            <Link href="/declaratii/new" className="text-sm text-green-600 font-medium hover:underline flex items-center gap-1">
              <span>+</span> Adaugă declarație nouă
            </Link>
          </div>
        </div>
      </div>

      {/* Calendar preview link */}
      <div className="card p-5 bg-gradient-to-r from-green-50 to-emerald-50 border-green-200">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-4">
            <span className="text-4xl">📅</span>
            <div>
              <h3 className="font-bold text-gray-900">Calendar Termene</h3>
              <p className="text-sm text-gray-600">Vizualizează toate termenele pe calendar lunar cu alertele aferente</p>
            </div>
          </div>
          <Link href="/calendar" className="btn-primary bg-green-600">
            Deschide Calendar →
          </Link>
        </div>
      </div>
    </div>
  )
}
