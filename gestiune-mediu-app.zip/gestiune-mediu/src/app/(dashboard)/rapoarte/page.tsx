import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { prisma } from '@/lib/prisma'
import Link from 'next/link'
import { format } from 'date-fns'
import { ro } from 'date-fns/locale'

export default async function RapoartePage() {
  const session = await getServerSession(authOptions)
  const isAdmin = session!.user.role === 'ADMIN'

  const rapoarte = await prisma.raport.findMany({
    where: isAdmin ? {} : { userId: session!.user.id },
    orderBy: { createdAt: 'desc' },
    include: { user: { select: { name: true } } },
  })

  const TIPURI: Record<string, string> = {
    LUNAR: '📅 Lunar', TRIMESTRIAL: '📊 Trimestrial', ANUAL: '📈 Anual', AD_HOC: '📋 Ad Hoc',
  }
  const STATUS: Record<string, string> = {
    IN_LUCRU: 'bg-yellow-100 text-yellow-800', DEPUS: 'bg-blue-100 text-blue-800',
    APROBAT: 'bg-green-100 text-green-800', RESPINS: 'bg-red-100 text-red-800', EXPIRAT: 'bg-gray-100 text-gray-600',
  }
  const STATUS_LABEL: Record<string, string> = {
    IN_LUCRU: 'În Lucru', DEPUS: 'Depus', APROBAT: 'Aprobat', RESPINS: 'Respins', EXPIRAT: 'Expirat',
  }

  // Termene importante legislatie Romania mediu
  const termeneImportante = [
    { luna: 'Ianuarie', termene: ['25 ian — Declarație taxă fond mediu (trim. IV)', 'Raportare anuală emisii (an precedent)'] },
    { luna: 'Februarie', termene: ['25 feb — Plată taxă fond mediu', 'Raportare anuală gestionare deșeuri'] },
    { luna: 'Aprilie', termene: ['25 apr — Declarație anuală AFM (termen final)', '15 apr — Raportare emisii GES'] },
    { luna: 'Iulie', termene: ['25 iul — Raportare semestrială deșeuri', 'Actualizare plan de management'] },
    { luna: 'Octombrie', termene: ['25 oct — Raportare trimestrială Q3', 'Verificare condiții autorizație'] },
    { luna: 'Decembrie', termene: ['15 dec — Planificare termene an următor', '31 dec — Inventar deșeuri anual'] },
  ]

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">📈 Rapoarte</h1>
          <p className="text-gray-500 mt-0.5">{rapoarte.length} rapoarte înregistrate</p>
        </div>
      </div>

      {/* Calendar legislativ */}
      <div className="card p-5">
        <h2 className="font-bold text-gray-900 mb-4 flex items-center gap-2">
          🗓️ Calendar Legislativ Mediu — Romania
        </h2>
        <div className="grid grid-cols-3 gap-3">
          {termeneImportante.map(t => (
            <div key={t.luna} className="border border-green-200 rounded-lg p-3 bg-green-50">
              <p className="font-semibold text-green-800 text-sm mb-2">{t.luna}</p>
              {t.termene.map((term, i) => (
                <p key={i} className="text-xs text-gray-600 mb-1 flex items-start gap-1">
                  <span className="text-green-500 mt-0.5">›</span> {term}
                </p>
              ))}
            </div>
          ))}
        </div>
      </div>

      {/* Rapoarte list */}
      <div className="card overflow-hidden">
        <div className="p-4 border-b border-gray-100 flex items-center justify-between">
          <h2 className="font-semibold text-gray-900">Rapoarte Înregistrate</h2>
        </div>
        {rapoarte.length === 0 ? (
          <div className="p-10 text-center">
            <div className="text-5xl mb-3">📈</div>
            <p className="text-gray-500">Nu ai adăugat încă rapoarte</p>
          </div>
        ) : (
          <table className="w-full">
            <thead>
              <tr className="bg-gray-50 text-xs font-semibold text-gray-500 uppercase">
                <th className="px-4 py-3 text-left">Raport</th>
                <th className="px-4 py-3 text-left">Tip</th>
                <th className="px-4 py-3 text-left">Perioadă</th>
                <th className="px-4 py-3 text-left">Status</th>
                <th className="px-4 py-3 text-left">Data</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-50">
              {rapoarte.map(r => (
                <tr key={r.id} className="hover:bg-gray-50">
                  <td className="px-4 py-3"><p className="text-sm font-medium text-gray-900">{r.titlu}</p></td>
                  <td className="px-4 py-3"><span className="text-xs bg-gray-100 px-2 py-1 rounded">{TIPURI[r.tip]}</span></td>
                  <td className="px-4 py-3 text-sm text-gray-600">{r.perioada}</td>
                  <td className="px-4 py-3"><span className={`text-xs px-2.5 py-0.5 rounded-full font-medium ${STATUS[r.status]}`}>{STATUS_LABEL[r.status]}</span></td>
                  <td className="px-4 py-3 text-sm text-gray-500">{format(new Date(r.createdAt), 'd MMM yyyy', { locale: ro })}</td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
    </div>
  )
}
