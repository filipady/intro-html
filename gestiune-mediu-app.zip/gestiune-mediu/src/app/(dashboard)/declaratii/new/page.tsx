'use client'
import { useState, FormEvent } from 'react'
import { useRouter } from 'next/navigation'
import Link from 'next/link'

const TIPURI = ['DECLARATIE_AFM','AUTORIZATIE_MEDIU','AVIZ_MEDIU','ACORD_MEDIU','BILANT_MEDIU','PLAN_MANAGEMENT','ALTA']
const TIP_LABEL: Record<string, string> = {
  DECLARATIE_AFM: '💰 Declarație AFM', AUTORIZATIE_MEDIU: '🔒 Autorizație Mediu',
  AVIZ_MEDIU: '📋 Aviz Mediu', ACORD_MEDIU: '🤝 Acord Mediu',
  BILANT_MEDIU: '📊 Bilanț Mediu', PLAN_MANAGEMENT: '📁 Plan Management', ALTA: '📄 Alta',
}
const JUDETE = ['Alba','Arad','Argeș','Bacău','Bihor','Bistrița-Năsăud','Botoșani','Brăila','Brașov',
  'Buzău','Călărași','Cluj','Constanța','Covasna','Dâmbovița','Dolj','Galați','Giurgiu','Gorj',
  'Harghita','Hunedoara','Ialomița','Iași','Ilfov','Maramureș','Mehedinți','Mureș','Neamț','Olt',
  'Prahova','Sălaj','Satu Mare','Sibiu','Suceava','Teleorman','Timiș','Tulcea','Vâlcea','Vaslui',
  'Vrancea','București']

export default function NewDeclaratiePage() {
  const router = useRouter()
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')
  const [form, setForm] = useState({
    tip: 'DECLARATIE_AFM', titlu: '', descriere: '', status: 'IN_LUCRU',
    dataEmitere: '', dataExpirare: '', numarDoc: '', autoritate: '', judet: 'Dâmbovița', observatii: '',
  })
  const set = (k: string) => (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) =>
    setForm(f => ({ ...f, [k]: e.target.value }))

  async function handleSubmit(ev: FormEvent) {
    ev.preventDefault(); setLoading(true); setError('')
    const res = await fetch('/api/declaratii', {
      method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(form),
    })
    const data = await res.json()
    if (!res.ok) { setError(data.error || 'Eroare'); setLoading(false); return }
    router.push('/declaratii'); router.refresh()
  }

  return (
    <div className="max-w-2xl mx-auto space-y-6">
      <div className="flex items-center gap-4">
        <Link href="/declaratii" className="text-gray-500 hover:text-gray-700">← Înapoi</Link>
        <h1 className="text-2xl font-bold text-gray-900">📄 Declarație / Document Nou</h1>
      </div>
      <div className="card p-6">
        {error && <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-lg mb-4 text-sm">⚠️ {error}</div>}
        <form onSubmit={handleSubmit} className="space-y-5">
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="label">Tip document *</label>
              <select className="input-field" value={form.tip} onChange={set('tip')}>
                {TIPURI.map(t => <option key={t} value={t}>{TIP_LABEL[t]}</option>)}
              </select>
            </div>
            <div>
              <label className="label">Status *</label>
              <select className="input-field" value={form.status} onChange={set('status')}>
                <option value="IN_LUCRU">🟡 În Lucru</option>
                <option value="DEPUS">🔵 Depus</option>
                <option value="APROBAT">🟢 Aprobat</option>
                <option value="RESPINS">🔴 Respins</option>
                <option value="EXPIRAT">⚫ Expirat</option>
              </select>
            </div>
          </div>
          <div>
            <label className="label">Titlu document *</label>
            <input className="input-field" value={form.titlu} onChange={set('titlu')}
              placeholder="ex: Autorizație de mediu - Hală producție 2024" required />
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="label">Număr document</label>
              <input className="input-field" value={form.numarDoc} onChange={set('numarDoc')} placeholder="ex: AM-2024-0142" />
            </div>
            <div>
              <label className="label">Autoritate emitentă</label>
              <input className="input-field" value={form.autoritate} onChange={set('autoritate')} placeholder="ex: APM Dâmbovița, AFM" />
            </div>
          </div>
          <div className="grid grid-cols-3 gap-4">
            <div>
              <label className="label">Județ</label>
              <select className="input-field" value={form.judet} onChange={set('judet')}>
                {JUDETE.map(j => <option key={j} value={j}>{j}</option>)}
              </select>
            </div>
            <div>
              <label className="label">Data emiterii</label>
              <input type="date" className="input-field" value={form.dataEmitere} onChange={set('dataEmitere')} />
            </div>
            <div>
              <label className="label">Data expirării</label>
              <input type="date" className="input-field" value={form.dataExpirare} onChange={set('dataExpirare')} />
            </div>
          </div>
          <div>
            <label className="label">Descriere</label>
            <textarea className="input-field min-h-[80px]" value={form.descriere}
              onChange={e => setForm(f => ({ ...f, descriere: e.target.value }))}
              placeholder="Activitate acoperită, condiții, observații..." />
          </div>
          <div>
            <label className="label">Observații interne</label>
            <textarea className="input-field min-h-[60px]" value={form.observatii}
              onChange={e => setForm(f => ({ ...f, observatii: e.target.value }))}
              placeholder="Note interne, acțiuni necesare..." />
          </div>
          <div className="flex gap-3 pt-2">
            <button type="submit" disabled={loading} className="btn-primary flex-1 justify-center">
              {loading ? '⏳ Se salvează...' : '✅ Salvează Document'}
            </button>
            <Link href="/declaratii" className="btn-secondary">Anulează</Link>
          </div>
        </form>
      </div>
    </div>
  )
}
