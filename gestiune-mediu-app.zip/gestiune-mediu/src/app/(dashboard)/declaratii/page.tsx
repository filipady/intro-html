import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { prisma } from '@/lib/prisma'
import Link from 'next/link'
import { format } from 'date-fns'
import { ro } from 'date-fns/locale'

const TIP_ICON: Record<string, string> = {
  DECLARATIE_AFM: '💰', AUTORIZATIE_MEDIU: '🔒', AVIZ_MEDIU: '📋',
  ACORD_MEDIU: '🤝', BILANT_MEDIU: '📊', PLAN_MANAGEMENT: '📁', ALTA: '📄',
}
const TIP_LABEL: Record<string, string> = {
  DECLARATIE_AFM: 'Declarație AFM', AUTORIZATIE_MEDIU: 'Autorizație Mediu',
  AVIZ_MEDIU: 'Aviz Mediu', ACORD_MEDIU: 'Acord Mediu',
  BILANT_MEDIU: 'Bilanț Mediu', PLAN_MANAGEMENT: 'Plan Management', ALTA: 'Alta',
}
const STATUS_BADGE: Record<string, string> = {
  IN_LUCRU: 'bg-yellow-100 text-yellow-800', DEPUS: 'bg-blue-100 text-blue-800',
  APROBAT: 'bg-green-100 text-green-800', RESPINS: 'bg-red-100 text-red-800',
  EXPIRAT: 'bg-gray-100 text-gray-600',
}
const STATUS_LABEL: Record<string, string> = {
  IN_LUCRU: 'În Lucru', DEPUS: 'Depus', APROBAT: 'Aprobat', RESPINS: 'Respins', EXPIRAT: 'Expirat',
}

export default async function DeclaratiiPage() {
  const session = await getServerSession(authOptions)
  const isAdmin = session!.user.role === 'ADMIN'

  const declaratii = await prisma.declaratie.findMany({
    where: isAdmin ? {} : { userId: session!.user.id },
    orderBy: { updatedAt: 'desc' },
    include: {
      user: { select: { name: true, firma: true } },
      termene: { where: { status: 'ACTIV' }, select: { id: true } },
    },
  })

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">📄 Declarații & Autorizații</h1>
          <p className="text-gray-500 mt-0.5">{declaratii.length} documente înregistrate</p>
        </div>
        <Link href="/declaratii/new" className="btn-primary">
          <span>+</span> Adaugă Document
        </Link>
      </div>

      {/* Filter tabs */}
      <div className="flex gap-2 flex-wrap">
        {Object.entries(TIP_LABEL).map(([tip, label]) => {
          const count = declaratii.filter(d => d.tip === tip).length
          return count > 0 ? (
            <span key={tip} className="inline-flex items-center gap-1 px-3 py-1 bg-white border border-gray-200 rounded-full text-sm text-gray-600">
              {TIP_ICON[tip]} {label} <span className="font-bold text-gray-900">{count}</span>
            </span>
          ) : null
        })}
      </div>

      {/* Table */}
      <div className="card overflow-hidden">
        {declaratii.length === 0 ? (
          <div className="p-12 text-center">
            <div className="text-5xl mb-3">📋</div>
            <p className="text-gray-500 mb-4">Nu ai adăugat încă nicio declarație</p>
            <Link href="/declaratii/new" className="btn-primary inline-flex">+ Adaugă prima declarație</Link>
          </div>
        ) : (
          <table className="w-full">
            <thead>
              <tr className="bg-gray-50 text-xs font-semibold text-gray-500 uppercase tracking-wider">
                <th className="px-4 py-3 text-left">Document</th>
                <th className="px-4 py-3 text-left">Tip</th>
                <th className="px-4 py-3 text-left">Status</th>
                <th className="px-4 py-3 text-left">Expirare</th>
                {isAdmin && <th className="px-4 py-3 text-left">Utilizator</th>}
                <th className="px-4 py-3 text-left">Termene</th>
                <th className="px-4 py-3 text-right">Acțiuni</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-50">
              {declaratii.map(d => (
                <tr key={d.id} className="hover:bg-gray-50">
                  <td className="px-4 py-3">
                    <div className="flex items-center gap-3">
                      <span className="text-2xl">{TIP_ICON[d.tip]}</span>
                      <div>
                        <p className="text-sm font-semibold text-gray-900">{d.titlu}</p>
                        {d.numarDoc && <p className="text-xs text-gray-500">Nr. {d.numarDoc}</p>}
                        {d.autoritate && <p className="text-xs text-gray-400">{d.autoritate} · {d.judet}</p>}
                      </div>
                    </div>
                  </td>
                  <td className="px-4 py-3">
                    <span className="text-xs bg-gray-100 text-gray-600 px-2 py-1 rounded">
                      {TIP_LABEL[d.tip]}
                    </span>
                  </td>
                  <td className="px-4 py-3">
                    <span className={`text-xs px-2.5 py-0.5 rounded-full font-medium ${STATUS_BADGE[d.status]}`}>
                      {STATUS_LABEL[d.status]}
                    </span>
                  </td>
                  <td className="px-4 py-3 text-sm text-gray-600">
                    {d.dataExpirare
                      ? format(new Date(d.dataExpirare), 'd MMM yyyy', { locale: ro })
                      : <span className="text-gray-400">—</span>}
                  </td>
                  {isAdmin && (
                    <td className="px-4 py-3 text-sm text-gray-600">
                      {d.user.name}
                      <p className="text-xs text-gray-400">{d.user.firma}</p>
                    </td>
                  )}
                  <td className="px-4 py-3">
                    {d.termene.length > 0 ? (
                      <span className="text-xs font-medium text-orange-600 bg-orange-50 px-2 py-0.5 rounded-full">
                        {d.termene.length} active
                      </span>
                    ) : (
                      <span className="text-xs text-gray-400">—</span>
                    )}
                  </td>
                  <td className="px-4 py-3 text-right">
                    <div className="flex items-center justify-end gap-2">
                      <Link href={`/declaratii/${d.id}`} className="text-xs text-green-600 hover:underline font-medium">Detalii</Link>
                      <Link href={`/declaratii/${d.id}/edit`} className="text-xs text-blue-600 hover:underline font-medium">Editare</Link>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
    </div>
  )
}
