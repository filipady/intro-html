'use client'
import { useState, useEffect, FormEvent } from 'react'
import { useSession } from 'next-auth/react'

export default function SetariPage() {
  const { data: session, update } = useSession()
  const [loading, setLoading] = useState(false)
  const [success, setSuccess] = useState('')
  const [form, setForm] = useState({ name: '', firma: '', cui: '', telefon: '', emailNotif: true })
  const [passForm, setPassForm] = useState({ currentPassword: '', newPassword: '', confirm: '' })
  const [passError, setPassError] = useState('')
  const [passSuccess, setPassSuccess] = useState('')

  useEffect(() => {
    if (session?.user) {
      fetch('/api/users/me').then(r => r.json()).then(d => {
        setForm({ name: d.name || '', firma: d.firma || '', cui: d.cui || '', telefon: d.telefon || '', emailNotif: d.emailNotif })
      })
    }
  }, [session])

  async function saveProfile(e: FormEvent) {
    e.preventDefault(); setLoading(true); setSuccess('')
    const res = await fetch('/api/users/me', { method: 'PATCH', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(form) })
    if (res.ok) { setSuccess('Profilul a fost salvat cu succes!') }
    setLoading(false)
  }

  async function changePassword(e: FormEvent) {
    e.preventDefault(); setPassError(''); setPassSuccess('')
    if (passForm.newPassword !== passForm.confirm) { setPassError('Parolele nu coincid'); return }
    if (passForm.newPassword.length < 8) { setPassError('Parola trebuie să aibă min. 8 caractere'); return }
    const res = await fetch('/api/users/password', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(passForm) })
    const data = await res.json()
    if (!res.ok) { setPassError(data.error || 'Eroare'); return }
    setPassSuccess('Parola a fost schimbată!'); setPassForm({ currentPassword: '', newPassword: '', confirm: '' })
  }

  return (
    <div className="max-w-2xl mx-auto space-y-6">
      <h1 className="text-2xl font-bold text-gray-900">⚙️ Setări Cont</h1>

      {/* Profile */}
      <div className="card p-6">
        <h2 className="font-bold text-gray-900 mb-5 flex items-center gap-2">👤 Profil</h2>
        {success && <div className="bg-green-50 border border-green-200 text-green-700 px-4 py-3 rounded-lg mb-4 text-sm">✅ {success}</div>}
        <form onSubmit={saveProfile} className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div><label className="label">Nume complet</label>
              <input className="input-field" value={form.name} onChange={e => setForm(f => ({ ...f, name: e.target.value }))} /></div>
            <div><label className="label">Telefon</label>
              <input className="input-field" value={form.telefon} onChange={e => setForm(f => ({ ...f, telefon: e.target.value }))} placeholder="07XXXXXXXX" /></div>
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div><label className="label">Firma</label>
              <input className="input-field" value={form.firma} onChange={e => setForm(f => ({ ...f, firma: e.target.value }))} /></div>
            <div><label className="label">CUI</label>
              <input className="input-field" value={form.cui} onChange={e => setForm(f => ({ ...f, cui: e.target.value }))} /></div>
          </div>

          {/* Email notifs */}
          <div className="flex items-center justify-between p-4 bg-green-50 border border-green-200 rounded-lg">
            <div>
              <p className="font-semibold text-gray-900 text-sm">📧 Notificări Email</p>
              <p className="text-xs text-gray-600 mt-0.5">Primește email cu 3 zile, 1 zi și în ziua scadenței pentru fiecare termen</p>
            </div>
            <button
              type="button"
              onClick={() => setForm(f => ({ ...f, emailNotif: !f.emailNotif }))}
              className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors ${form.emailNotif ? 'bg-green-600' : 'bg-gray-200'}`}
            >
              <span className={`inline-block h-4 w-4 transform rounded-full bg-white transition-transform ${form.emailNotif ? 'translate-x-6' : 'translate-x-1'}`} />
            </button>
          </div>

          <button type="submit" disabled={loading} className="btn-primary">
            {loading ? '⏳ Se salvează...' : '💾 Salvează Profilul'}
          </button>
        </form>
      </div>

      {/* Password */}
      <div className="card p-6">
        <h2 className="font-bold text-gray-900 mb-5 flex items-center gap-2">🔑 Schimbă Parola</h2>
        {passError && <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-lg mb-4 text-sm">⚠️ {passError}</div>}
        {passSuccess && <div className="bg-green-50 border border-green-200 text-green-700 px-4 py-3 rounded-lg mb-4 text-sm">✅ {passSuccess}</div>}
        <form onSubmit={changePassword} className="space-y-4">
          <div><label className="label">Parola curentă</label>
            <input type="password" className="input-field" value={passForm.currentPassword}
              onChange={e => setPassForm(f => ({ ...f, currentPassword: e.target.value }))} required /></div>
          <div className="grid grid-cols-2 gap-4">
            <div><label className="label">Parolă nouă</label>
              <input type="password" className="input-field" value={passForm.newPassword}
                onChange={e => setPassForm(f => ({ ...f, newPassword: e.target.value }))} required /></div>
            <div><label className="label">Confirmă parola</label>
              <input type="password" className="input-field" value={passForm.confirm}
                onChange={e => setPassForm(f => ({ ...f, confirm: e.target.value }))} required /></div>
          </div>
          <button type="submit" className="btn-primary">🔐 Schimbă Parola</button>
        </form>
      </div>

      {/* Account info */}
      <div className="card p-6 bg-gray-50">
        <h2 className="font-bold text-gray-700 mb-3 text-sm">ℹ️ Informații Cont</h2>
        <div className="space-y-2 text-sm text-gray-600">
          <p><span className="font-medium">Email:</span> {session?.user?.email}</p>
          <p><span className="font-medium">Rol:</span> <span className="bg-green-100 text-green-700 px-2 py-0.5 rounded text-xs font-bold">{session?.user?.role}</span></p>
        </div>
      </div>
    </div>
  )
}
