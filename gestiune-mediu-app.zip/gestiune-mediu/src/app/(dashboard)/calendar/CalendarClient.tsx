'use client'
import { useState } from 'react'
import { format, startOfMonth, endOfMonth, eachDayOfInterval, getDay, isSameDay, isSameMonth, isToday, differenceInDays } from 'date-fns'
import { ro } from 'date-fns/locale'
import Link from 'next/link'

interface CalEvent {
  id: string
  titlu: string
  dataScadenta: string
  tip: string
  prioritate: string
  status: string
  userName: string
}

const PRIORITATE_COLOR: Record<string, string> = {
  CRITICA: 'bg-red-500',
  RIDICATA: 'bg-orange-500',
  MEDIE: 'bg-yellow-500',
  SCAZUTA: 'bg-green-500',
}

const PRIORITATE_TEXT: Record<string, string> = {
  CRITICA: 'text-red-700 bg-red-50 border-red-200',
  RIDICATA: 'text-orange-700 bg-orange-50 border-orange-200',
  MEDIE: 'text-yellow-700 bg-yellow-50 border-yellow-200',
  SCAZUTA: 'text-green-700 bg-green-50 border-green-200',
}

const ZILE_SAPT = ['Lun', 'Mar', 'Mie', 'Joi', 'Vin', 'Sâm', 'Dum']

export default function CalendarClient({ events, isAdmin }: { events: CalEvent[], isAdmin: boolean }) {
  const [currentDate, setCurrentDate] = useState(new Date())
  const [selectedDay, setSelectedDay] = useState<Date | null>(null)

  const monthStart = startOfMonth(currentDate)
  const monthEnd = endOfMonth(currentDate)
  const days = eachDayOfInterval({ start: monthStart, end: monthEnd })

  // Fill leading empty days (Monday = 0)
  const startDow = (getDay(monthStart) + 6) % 7 // Convert Sunday=0 to Monday=0

  function getEventsForDay(day: Date) {
    return events.filter(e => isSameDay(new Date(e.dataScadenta), day))
  }

  function prevMonth() {
    setCurrentDate(d => new Date(d.getFullYear(), d.getMonth() - 1, 1))
    setSelectedDay(null)
  }
  function nextMonth() {
    setCurrentDate(d => new Date(d.getFullYear(), d.getMonth() + 1, 1))
    setSelectedDay(null)
  }

  const selectedEvents = selectedDay ? getEventsForDay(selectedDay) : []
  const azi = new Date()

  // Stats for current month
  const monthEvents = events.filter(e => isSameMonth(new Date(e.dataScadenta), currentDate))
  const urgente = monthEvents.filter(e => {
    const zile = differenceInDays(new Date(e.dataScadenta), azi)
    return zile <= 7 && zile >= 0
  })
  const depasit = events.filter(e => differenceInDays(new Date(e.dataScadenta), azi) < 0)

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-gray-900 flex items-center gap-2">
            📅 Calendar Termene
          </h1>
          <p className="text-gray-500 mt-0.5">Toate termenele de mediu vizualizate pe calendar</p>
        </div>
        <Link href="/termene/new" className="btn-primary">
          <span>+</span> Termen Nou
        </Link>
      </div>

      {/* Quick stats */}
      <div className="grid grid-cols-3 gap-4">
        <div className="card p-4 border-blue-200 bg-blue-50">
          <p className="text-2xl font-bold text-blue-700">{monthEvents.length}</p>
          <p className="text-sm text-blue-600">Termene în {format(currentDate, 'MMMM', { locale: ro })}</p>
        </div>
        <div className="card p-4 border-orange-200 bg-orange-50">
          <p className="text-2xl font-bold text-orange-700">{urgente.length}</p>
          <p className="text-sm text-orange-600">Scadente în 7 zile</p>
        </div>
        <div className="card p-4 border-red-200 bg-red-50">
          <p className="text-2xl font-bold text-red-700">{depasit.length}</p>
          <p className="text-sm text-red-600">Termene depășite</p>
        </div>
      </div>

      <div className="grid grid-cols-3 gap-6">
        {/* Calendar - 2/3 */}
        <div className="col-span-2 card">
          {/* Month navigation */}
          <div className="p-4 border-b border-gray-100 flex items-center justify-between">
            <button onClick={prevMonth} className="p-2 hover:bg-gray-100 rounded-lg transition-colors text-gray-600 font-bold text-lg">
              ‹
            </button>
            <h2 className="text-lg font-bold text-gray-900 capitalize">
              {format(currentDate, 'MMMM yyyy', { locale: ro })}
            </h2>
            <button onClick={nextMonth} className="p-2 hover:bg-gray-100 rounded-lg transition-colors text-gray-600 font-bold text-lg">
              ›
            </button>
          </div>

          {/* Day headers */}
          <div className="grid grid-cols-7 border-b border-gray-100">
            {ZILE_SAPT.map(z => (
              <div key={z} className="py-2 text-center text-xs font-semibold text-gray-500 uppercase tracking-wide">
                {z}
              </div>
            ))}
          </div>

          {/* Calendar grid */}
          <div className="grid grid-cols-7">
            {/* Leading empty cells */}
            {Array.from({ length: startDow }).map((_, i) => (
              <div key={`empty-${i}`} className="h-24 border-b border-r border-gray-50" />
            ))}

            {days.map(day => {
              const dayEvents = getEventsForDay(day)
              const isSelected = selectedDay && isSameDay(day, selectedDay)
              const todayDay = isToday(day)

              return (
                <button
                  key={day.toISOString()}
                  onClick={() => setSelectedDay(isSameDay(day, selectedDay || new Date(0)) ? null : day)}
                  className={`h-24 border-b border-r border-gray-100 p-1.5 text-left transition-colors relative ${
                    isSelected ? 'bg-green-50 border-green-200' : 'hover:bg-gray-50'
                  }`}
                >
                  <span className={`text-sm font-medium w-7 h-7 flex items-center justify-center rounded-full mb-1 ${
                    todayDay ? 'bg-green-600 text-white' : 'text-gray-700'
                  }`}>
                    {format(day, 'd')}
                  </span>
                  <div className="space-y-0.5">
                    {dayEvents.slice(0, 2).map(e => (
                      <div
                        key={e.id}
                        className={`text-xs px-1.5 py-0.5 rounded truncate font-medium ${
                          PRIORITATE_COLOR[e.prioritate]
                        } text-white`}
                      >
                        {e.titlu.slice(0, 18)}
                      </div>
                    ))}
                    {dayEvents.length > 2 && (
                      <div className="text-xs text-gray-500 pl-1">+{dayEvents.length - 2} mai mult</div>
                    )}
                  </div>
                </button>
              )
            })}
          </div>

          {/* Legend */}
          <div className="p-4 border-t border-gray-100 flex items-center gap-4">
            <span className="text-xs text-gray-500 font-medium">Prioritate:</span>
            {Object.entries(PRIORITATE_COLOR).map(([p, c]) => (
              <span key={p} className="flex items-center gap-1.5 text-xs text-gray-600">
                <span className={`w-3 h-3 rounded-full ${c}`} />
                {p.charAt(0) + p.slice(1).toLowerCase()}
              </span>
            ))}
          </div>
        </div>

        {/* Side panel - 1/3 */}
        <div className="space-y-4">
          {/* Selected day events */}
          <div className="card">
            <div className="p-4 border-b border-gray-100">
              <h3 className="font-bold text-gray-900 text-sm">
                {selectedDay
                  ? `📌 ${format(selectedDay, 'd MMMM yyyy', { locale: ro })}`
                  : '📌 Selectează o zi'}
              </h3>
            </div>
            <div className="p-3">
              {!selectedDay ? (
                <p className="text-sm text-gray-400 text-center py-4">
                  Apasă pe o zi pentru a vedea termenele
                </p>
              ) : selectedEvents.length === 0 ? (
                <p className="text-sm text-gray-400 text-center py-4">✅ Niciun termen în această zi</p>
              ) : (
                <div className="space-y-2">
                  {selectedEvents.map(e => (
                    <Link key={e.id} href={`/termene/${e.id}`} className="block">
                      <div className={`border rounded-lg p-3 text-xs ${PRIORITATE_TEXT[e.prioritate]} hover:shadow-sm transition-shadow`}>
                        <p className="font-bold mb-1">{e.titlu}</p>
                        <p className="opacity-75">{e.tip.replace(/_/g, ' ')}</p>
                        {isAdmin && <p className="opacity-60 mt-1">👤 {e.userName}</p>}
                      </div>
                    </Link>
                  ))}
                </div>
              )}
            </div>
          </div>

          {/* Upcoming */}
          <div className="card">
            <div className="p-4 border-b border-gray-100">
              <h3 className="font-bold text-gray-900 text-sm">🔔 Urmează în curând</h3>
            </div>
            <div className="p-3 space-y-2 max-h-80 overflow-y-auto">
              {events
                .filter(e => {
                  const zile = differenceInDays(new Date(e.dataScadenta), azi)
                  return zile >= 0 && zile <= 30
                })
                .slice(0, 8)
                .map(e => {
                  const zile = differenceInDays(new Date(e.dataScadenta), azi)
                  return (
                    <div key={e.id} className="flex items-center gap-2">
                      <span className={`w-2 h-2 rounded-full flex-shrink-0 ${PRIORITATE_COLOR[e.prioritate]}`} />
                      <div className="flex-1 min-w-0">
                        <p className="text-xs font-medium text-gray-900 truncate">{e.titlu}</p>
                        <p className="text-xs text-gray-500">
                          {format(new Date(e.dataScadenta), 'd MMM', { locale: ro })} ·{' '}
                          {zile === 0 ? 'Azi' : `${zile}z`}
                        </p>
                      </div>
                    </div>
                  )
                })}
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
