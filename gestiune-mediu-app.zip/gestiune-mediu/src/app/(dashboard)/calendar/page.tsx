import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { prisma } from '@/lib/prisma'
import CalendarClient from './CalendarClient'

export default async function CalendarPage() {
  const session = await getServerSession(authOptions)
  const isAdmin = session!.user.role === 'ADMIN'

  const termene = await prisma.termen.findMany({
    where: isAdmin ? { status: { in: ['ACTIV', 'DEPASIT'] } } : {
      userId: session!.user.id,
      status: { in: ['ACTIV', 'DEPASIT'] },
    },
    include: { user: { select: { name: true } } },
    orderBy: { dataScadenta: 'asc' },
  })

  const events = termene.map(t => ({
    id: t.id,
    titlu: t.titlu,
    dataScadenta: t.dataScadenta.toISOString(),
    tip: t.tip,
    prioritate: t.prioritate,
    status: t.status,
    userName: t.user.name,
  }))

  return <CalendarClient events={events} isAdmin={isAdmin} />
}
