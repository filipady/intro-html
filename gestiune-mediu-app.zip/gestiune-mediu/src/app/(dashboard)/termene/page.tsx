import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { prisma } from '@/lib/prisma'
import Link from 'next/link'
import { format, differenceInDays } from 'date-fns'
import { ro } from 'date-fns/locale'

const TIP_LABEL: Record<string, string> = {
  RAPORTARE_LUNARA: 'Raportare Lunară',
  RAPORTARE_TRIMESTRIALA: 'Raportare Trimestrială',
  RAPORTARE_ANUALA: 'Raportare Anuală',
  REINNOIRE_AUTORIZATIE: 'Reînnoire Autorizație',
  PLATA_TAXA: 'Plată Taxă',
  DEPUNERE_DECLARATIE: 'Depunere Declarație',
  CONTROL_PLANIFICAT: 'Control Planificat',
  ALT_TERMEN: 'Alt Termen',
}

function ZileChip({ zile }: { zile: number }) {
  if (zile < 0) return <span className="px-2 py-0.5 rounded-full text-xs font-bold bg-red-100 text-red-800">Depășit {Math.abs(zile)}z</span>
  if (zile === 0) return <span className="px-2 py-0.5 rounded-full text-xs font-bold bg-red-100 text-red-800 animate-pulse">AZI</span>
  if (zile === 1) return <span className="px-2 py-0.5 rounded-full text-xs font-bold bg-orange-100 text-orange-800">Mâine</span>
  if (zile <= 7) return <span className="px-2 py-0.5 rounded-full text-xs font-bold bg-orange-100 text-orange-800">{zile} zile</span>
  if (zile <= 30) return <span className="px-2 py-0.5 rounded-full text-xs font-medium bg-yellow-100 text-yellow-800">{zile} zile</span>
  return <span className="px-2 py-0.5 rounded-full text-xs font-medium bg-gray-100 text-gray-600">{zile} zile</span>
}

export default async function TermenePage() {
  const session = await getServerSession(authOptions)
  const isAdmin = session!.user.role === 'ADMIN'

  const termene = await prisma.termen.findMany({
    where: isAdmin ? {} : { userId: session!.user.id },
    orderBy: { dataScadenta: 'asc' },
    include: {
      user: { select: { name: true, firma: true } },
      declaratie: { select: { titlu: true } },
    },
  })

  const azi = new Date()
  const termeneActive = termene.filter(t => t.status !== 'FINALIZAT' && t.status !== 'ANULAT')
  const termeneFinalizate = termene.filter(t => t.status === 'FINALIZAT' || t.status === 'ANULAT')

  const PRIO_BADGE: Record<string, string> = {
    CRITICA: 'badge-critica', RIDICATA: 'badge-ridicata',
    MEDIE: 'badge-medie', SCAZUTA: 'badge-scazuta',
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">⏰ Termene Scadente</h1>
          <p className="text-gray-500 mt-0.5">{termeneActive.length} termene active</p>
        </div>
        <Link href="/termene/new" className="btn-primary">
          <span>+</span> Termen Nou
        </Link>
      </div>

      {/* Active termene */}
      <div className="card overflow-hidden">
        <div className="p-4 border-b border-gray-100 bg-gray-50">
          <h2 className="font-semibold text-gray-900">Termene Active & Depășite</h2>
        </div>
        {termeneActive.length === 0 ? (
          <div className="p-10 text-center">
            <div className="text-5xl mb-3">✅</div>
            <p className="text-gray-500">Nu sunt termene active</p>
            <Link href="/termene/new" className="btn-primary mt-4 inline-flex">+ Adaugă primul termen</Link>
          </div>
        ) : (
          <table className="w-full">
            <thead>
              <tr className="text-xs font-semibold text-gray-500 uppercase tracking-wider border-b border-gray-100">
                <th className="px-4 py-3 text-left">Termen</th>
                <th className="px-4 py-3 text-left">Tip</th>
                <th className="px-4 py-3 text-left">Scadență</th>
                <th className="px-4 py-3 text-left">Prioritate</th>
                {isAdmin && <th className="px-4 py-3 text-left">Utilizator</th>}
                <th className="px-4 py-3 text-right">Acțiuni</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-50">
              {termeneActive.map(t => {
                const zile = differenceInDays(new Date(t.dataScadenta), azi)
                return (
                  <tr key={t.id} className={`hover:bg-gray-50 ${zile < 0 ? 'bg-red-50/30' : ''}`}>
                    <td className="px-4 py-3">
                      <div>
                        <p className="text-sm font-semibold text-gray-900">{t.titlu}</p>
                        {t.declaratie && (
                          <p className="text-xs text-gray-500 mt-0.5">📄 {t.declaratie.titlu}</p>
                        )}
                        {t.descriere && <p className="text-xs text-gray-400 mt-0.5 truncate max-w-xs">{t.descriere}</p>}
                      </div>
                    </td>
                    <td className="px-4 py-3">
                      <span className="text-xs text-gray-600 bg-gray-100 px-2 py-1 rounded">
                        {TIP_LABEL[t.tip] || t.tip}
                      </span>
                    </td>
                    <td className="px-4 py-3">
                      <div>
                        <p className="text-sm text-gray-900">
                          {format(new Date(t.dataScadenta), 'd MMM yyyy', { locale: ro })}
                        </p>
                        <ZileChip zile={zile} />
                      </div>
                    </td>
                    <td className="px-4 py-3">
                      <span className={PRIO_BADGE[t.prioritate]}>
                        {t.prioritate.charAt(0) + t.prioritate.slice(1).toLowerCase()}
                      </span>
                    </td>
                    {isAdmin && (
                      <td className="px-4 py-3 text-sm text-gray-600">
                        {t.user.name}<br />
                        <span className="text-xs text-gray-400">{t.user.firma}</span>
                      </td>
                    )}
                    <td className="px-4 py-3 text-right">
                      <div className="flex items-center justify-end gap-2">
                        <Link href={`/termene/${t.id}`} className="text-xs text-green-600 hover:underline font-medium">
                          Detalii
                        </Link>
                        <Link href={`/termene/${t.id}/edit`} className="text-xs text-blue-600 hover:underline font-medium">
                          Editare
                        </Link>
                      </div>
                    </td>
                  </tr>
                )
              })}
            </tbody>
          </table>
        )}
      </div>

      {/* Finalizate */}
      {termeneFinalizate.length > 0 && (
        <div className="card overflow-hidden opacity-60">
          <div className="p-4 border-b border-gray-100 bg-gray-50">
            <h2 className="font-semibold text-gray-700 text-sm">Finalizate / Anulate ({termeneFinalizate.length})</h2>
          </div>
          <div className="divide-y divide-gray-50">
            {termeneFinalizate.slice(0, 5).map(t => (
              <div key={t.id} className="px-4 py-3 flex items-center gap-3">
                <span className="text-sm line-through text-gray-400">{t.titlu}</span>
                <span className={`text-xs px-2 py-0.5 rounded-full ${t.status === 'FINALIZAT' ? 'bg-green-100 text-green-700' : 'bg-gray-100 text-gray-500'}`}>
                  {t.status}
                </span>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  )
}
