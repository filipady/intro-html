'use client'
import { useState, FormEvent } from 'react'
import { useRouter } from 'next/navigation'
import Link from 'next/link'

const TIPURI = [
  'RAPORTARE_LUNARA', 'RAPORTARE_TRIMESTRIALA', 'RAPORTARE_ANUALA',
  'REINNOIRE_AUTORIZATIE', 'PLATA_TAXA', 'DEPUNERE_DECLARATIE',
  'CONTROL_PLANIFICAT', 'ALT_TERMEN',
]
const TIP_LABEL: Record<string, string> = {
  RAPORTARE_LUNARA: 'Raportare Lunară', RAPORTARE_TRIMESTRIALA: 'Raportare Trimestrială',
  RAPORTARE_ANUALA: 'Raportare Anuală', REINNOIRE_AUTORIZATIE: 'Reînnoire Autorizație',
  PLATA_TAXA: 'Plată Taxă', DEPUNERE_DECLARATIE: 'Depunere Declarație',
  CONTROL_PLANIFICAT: 'Control Planificat', ALT_TERMEN: 'Alt Termen',
}

// Termene legale standard Romania
const TERMENE_STANDARD = [
  { label: '📅 Raportare lunară deșeuri (25 ale lunii)', tip: 'RAPORTARE_LUNARA', prioritate: 'RIDICATA', ziua: 25 },
  { label: '📊 Raportare trimestrială APM', tip: 'RAPORTARE_TRIMESTRIALA', prioritate: 'RIDICATA', ziua: null },
  { label: '💰 Plată taxă fond mediu (25 ale lunii)', tip: 'PLATA_TAXA', prioritate: 'CRITICA', ziua: 25 },
  { label: '📋 Depunere declarație AFM (25 aprilie)', tip: 'DEPUNERE_DECLARATIE', prioritate: 'CRITICA', ziua: null },
]

export default function NewTermenPage() {
  const router = useRouter()
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')
  const [form, setForm] = useState({
    titlu: '', descriere: '', dataScadenta: '', tip: 'RAPORTARE_LUNARA',
    prioritate: 'MEDIE', declaratieId: '',
  })

  const set = (k: string) => (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) =>
    setForm(f => ({ ...f, [k]: e.target.value }))

  async function handleSubmit(ev: FormEvent) {
    ev.preventDefault()
    if (!form.dataScadenta) { setError('Data scadenței este obligatorie.'); return }
    setLoading(true); setError('')
    const res = await fetch('/api/termene', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(form),
    })
    const data = await res.json()
    if (!res.ok) { setError(data.error || 'Eroare'); setLoading(false); return }
    router.push('/termene')
    router.refresh()
  }

  function aplicaTemplate(t: typeof TERMENE_STANDARD[0]) {
    const azi = new Date()
    let data = new Date()
    if (t.ziua) {
      data.setDate(t.ziua)
      if (data <= azi) data.setMonth(data.getMonth() + 1)
    } else {
      data.setDate(data.getDate() + 30)
    }
    setForm(f => ({
      ...f, tip: t.tip, prioritate: t.prioritate,
      dataScadenta: data.toISOString().split('T')[0],
    }))
  }

  return (
    <div className="max-w-2xl mx-auto space-y-6">
      <div className="flex items-center gap-4">
        <Link href="/termene" className="text-gray-500 hover:text-gray-700">← Înapoi</Link>
        <h1 className="text-2xl font-bold text-gray-900">⏰ Termen Nou</h1>
      </div>

      {/* Quick templates */}
      <div className="card p-4">
        <p className="text-sm font-semibold text-gray-700 mb-3">⚡ Termene legislative standard Romania:</p>
        <div className="grid grid-cols-2 gap-2">
          {TERMENE_STANDARD.map((t, i) => (
            <button key={i} onClick={() => aplicaTemplate(t)}
              className="text-left text-xs p-2.5 border border-green-200 rounded-lg hover:bg-green-50 text-gray-700 transition-colors">
              {t.label}
            </button>
          ))}
        </div>
      </div>

      {/* Form */}
      <div className="card p-6">
        {error && <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-lg mb-4 text-sm">⚠️ {error}</div>}
        <form onSubmit={handleSubmit} className="space-y-5">
          <div>
            <label className="label">Titlu termen *</label>
            <input className="input-field" value={form.titlu} onChange={set('titlu')}
              placeholder="ex: Raportare lunară deșeuri - Ianuarie 2024" required />
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="label">Tip termen *</label>
              <select className="input-field" value={form.tip} onChange={set('tip')}>
                {TIPURI.map(t => <option key={t} value={t}>{TIP_LABEL[t]}</option>)}
              </select>
            </div>
            <div>
              <label className="label">Prioritate *</label>
              <select className="input-field" value={form.prioritate} onChange={set('prioritate')}>
                <option value="SCAZUTA">🟢 Scăzută</option>
                <option value="MEDIE">🟡 Medie</option>
                <option value="RIDICATA">🟠 Ridicată</option>
                <option value="CRITICA">🔴 Critică</option>
              </select>
            </div>
          </div>

          <div>
            <label className="label">Data scadenței *</label>
            <input type="date" className="input-field" value={form.dataScadenta} onChange={set('dataScadenta')} required />
          </div>

          <div>
            <label className="label">Descriere (opțional)</label>
            <textarea className="input-field min-h-[80px]" value={form.descriere}
              onChange={e => setForm(f => ({ ...f, descriere: e.target.value }))}
              placeholder="Detalii suplimentare despre acest termen..." />
          </div>

          <div>
            <label className="label">ID Declarație asociată (opțional)</label>
            <input className="input-field" value={form.declaratieId} onChange={set('declaratieId')}
              placeholder="Lasă gol dacă nu e asociat cu o declarație" />
          </div>

          <div className="bg-blue-50 border border-blue-200 rounded-lg p-3 text-xs text-blue-700">
            🔔 <strong>Notificări automate:</strong> Vei primi email cu 3 zile înainte, cu 1 zi înainte și în ziua scadenței.
          </div>

          <div className="flex gap-3 pt-2">
            <button type="submit" disabled={loading} className="btn-primary flex-1 justify-center">
              {loading ? '⏳ Se salvează...' : '✅ Salvează Termen'}
            </button>
            <Link href="/termene" className="btn-secondary">Anulează</Link>
          </div>
        </form>
      </div>
    </div>
  )
}
