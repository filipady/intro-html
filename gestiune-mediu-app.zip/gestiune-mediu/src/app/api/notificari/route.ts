import { NextRequest, NextResponse } from 'next/server'
import { checkAndSendNotificari } from '@/lib/notifications'

// This endpoint is called by a cron job (ex: Vercel Cron, cron-job.org)
// Protect with a secret key
export async function GET(req: NextRequest) {
  const authHeader = req.headers.get('authorization')
  const cronSecret = process.env.CRON_SECRET || 'secret-cron-key'

  if (authHeader !== `Bearer ${cronSecret}`) {
    return NextResponse.json({ error: 'Neautorizat' }, { status: 401 })
  }

  try {
    const result = await checkAndSendNotificari()
    return NextResponse.json({
      success: true,
      message: `Verificat ${result.verificate} termene, trimis ${result.emailsTrimise} emailuri`,
      ...result,
    })
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 })
  }
}

// Manual trigger from admin dashboard
export async function POST(req: NextRequest) {
  const { searchParams } = new URL(req.url)
  const secret = searchParams.get('secret')

  if (secret !== (process.env.CRON_SECRET || 'secret-cron-key')) {
    return NextResponse.json({ error: 'Neautorizat' }, { status: 401 })
  }

  const result = await checkAndSendNotificari()
  return NextResponse.json({ success: true, ...result })
}
