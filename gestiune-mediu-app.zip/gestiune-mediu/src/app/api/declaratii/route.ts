import { NextRequest, NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { prisma } from '@/lib/prisma'

export async function GET(req: NextRequest) {
  const session = await getServerSession(authOptions)
  if (!session) return NextResponse.json({ error: 'Neautorizat' }, { status: 401 })
  const isAdmin = session.user.role === 'ADMIN'
  const declaratii = await prisma.declaratie.findMany({
    where: isAdmin ? {} : { userId: session.user.id },
    orderBy: { updatedAt: 'desc' },
    include: { termene: { select: { id: true, status: true } } },
  })
  return NextResponse.json(declaratii)
}

export async function POST(req: NextRequest) {
  const session = await getServerSession(authOptions)
  if (!session) return NextResponse.json({ error: 'Neautorizat' }, { status: 401 })
  try {
    const body = await req.json()
    const declaratie = await prisma.declaratie.create({
      data: {
        tip: body.tip,
        titlu: body.titlu,
        descriere: body.descriere || null,
        status: body.status || 'IN_LUCRU',
        dataEmitere: body.dataEmitere ? new Date(body.dataEmitere) : null,
        dataExpirare: body.dataExpirare ? new Date(body.dataExpirare) : null,
        numarDoc: body.numarDoc || null,
        autoritate: body.autoritate || null,
        judet: body.judet || null,
        observatii: body.observatii || null,
        userId: session.user.id,
      },
    })
    return NextResponse.json(declaratie, { status: 201 })
  } catch (err) {
    return NextResponse.json({ error: 'Eroare server' }, { status: 500 })
  }
}
