import { NextRequest, NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { prisma } from '@/lib/prisma'

export async function GET() {
  const session = await getServerSession(authOptions)
  if (!session) return NextResponse.json({ error: 'Neautorizat' }, { status: 401 })
  const user = await prisma.user.findUnique({
    where: { id: session.user.id },
    select: { id: true, name: true, email: true, role: true, firma: true, cui: true, telefon: true, emailNotif: true },
  })
  return NextResponse.json(user)
}

export async function PATCH(req: NextRequest) {
  const session = await getServerSession(authOptions)
  if (!session) return NextResponse.json({ error: 'Neautorizat' }, { status: 401 })
  const body = await req.json()
  const user = await prisma.user.update({
    where: { id: session.user.id },
    data: {
      name: body.name,
      firma: body.firma || null,
      cui: body.cui || null,
      telefon: body.telefon || null,
      emailNotif: body.emailNotif,
    },
    select: { id: true, name: true, email: true, firma: true },
  })
  return NextResponse.json(user)
}
