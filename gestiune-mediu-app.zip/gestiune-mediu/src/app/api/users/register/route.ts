import { NextRequest, NextResponse } from 'next/server'
import bcrypt from 'bcryptjs'
import { prisma } from '@/lib/prisma'
import { sendWelcomeEmail } from '@/lib/email'

export async function POST(req: NextRequest) {
  try {
    const { name, email, password, firma, cui } = await req.json()

    if (!name || !email || !password) {
      return NextResponse.json({ error: 'Câmpuri obligatorii lipsă' }, { status: 400 })
    }
    if (password.length < 8) {
      return NextResponse.json({ error: 'Parola trebuie să aibă minimum 8 caractere' }, { status: 400 })
    }

    const exists = await prisma.user.findUnique({ where: { email } })
    if (exists) {
      return NextResponse.json({ error: 'Există deja un cont cu acest email' }, { status: 409 })
    }

    const hashedPassword = await bcrypt.hash(password, 12)
    const user = await prisma.user.create({
      data: { name, email, password: hashedPassword, firma: firma || null, cui: cui || null },
    })

    // Send welcome email (non-blocking)
    sendWelcomeEmail(email, name, password).catch(console.error)

    return NextResponse.json({ id: user.id, email: user.email, name: user.name }, { status: 201 })
  } catch (err) {
    return NextResponse.json({ error: 'Eroare server' }, { status: 500 })
  }
}
