import { NextRequest, NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { prisma } from '@/lib/prisma'

export async function GET(req: NextRequest) {
  const session = await getServerSession(authOptions)
  if (!session) return NextResponse.json({ error: 'Neautorizat' }, { status: 401 })
  const isAdmin = session.user.role === 'ADMIN'
  const termene = await prisma.termen.findMany({
    where: isAdmin ? {} : { userId: session.user.id },
    orderBy: { dataScadenta: 'asc' },
    include: {
      user: { select: { name: true } },
      declaratie: { select: { titlu: true } },
    },
  })
  return NextResponse.json(termene)
}

export async function POST(req: NextRequest) {
  const session = await getServerSession(authOptions)
  if (!session) return NextResponse.json({ error: 'Neautorizat' }, { status: 401 })
  try {
    const body = await req.json()
    if (!body.dataScadenta) return NextResponse.json({ error: 'Data scadenței este obligatorie' }, { status: 400 })
    const termen = await prisma.termen.create({
      data: {
        titlu: body.titlu,
        descriere: body.descriere || null,
        dataScadenta: new Date(body.dataScadenta),
        tip: body.tip,
        prioritate: body.prioritate || 'MEDIE',
        status: 'ACTIV',
        declaratieId: body.declaratieId || null,
        userId: session.user.id,
      },
    })
    return NextResponse.json(termen, { status: 201 })
  } catch (err) {
    return NextResponse.json({ error: 'Eroare server' }, { status: 500 })
  }
}
