import { NextRequest, NextResponse } from 'next/server'
import { getServerSession } from 'next-auth'
import { authOptions } from '@/lib/auth'
import { prisma } from '@/lib/prisma'

export async function GET(req: NextRequest, { params }: { params: { id: string } }) {
  const session = await getServerSession(authOptions)
  if (!session) return NextResponse.json({ error: 'Neautorizat' }, { status: 401 })
  const termen = await prisma.termen.findFirst({
    where: { id: params.id, ...(session.user.role !== 'ADMIN' ? { userId: session.user.id } : {}) },
    include: { user: true, declaratie: true },
  })
  if (!termen) return NextResponse.json({ error: 'Nu găsit' }, { status: 404 })
  return NextResponse.json(termen)
}

export async function PATCH(req: NextRequest, { params }: { params: { id: string } }) {
  const session = await getServerSession(authOptions)
  if (!session) return NextResponse.json({ error: 'Neautorizat' }, { status: 401 })
  const body = await req.json()
  const termen = await prisma.termen.updateMany({
    where: { id: params.id, ...(session.user.role !== 'ADMIN' ? { userId: session.user.id } : {}) },
    data: {
      ...(body.titlu && { titlu: body.titlu }),
      ...(body.descriere !== undefined && { descriere: body.descriere }),
      ...(body.dataScadenta && { dataScadenta: new Date(body.dataScadenta) }),
      ...(body.tip && { tip: body.tip }),
      ...(body.prioritate && { prioritate: body.prioritate }),
      ...(body.status && { status: body.status }),
    },
  })
  return NextResponse.json(termen)
}

export async function DELETE(req: NextRequest, { params }: { params: { id: string } }) {
  const session = await getServerSession(authOptions)
  if (!session) return NextResponse.json({ error: 'Neautorizat' }, { status: 401 })
  await prisma.termen.deleteMany({
    where: { id: params.id, ...(session.user.role !== 'ADMIN' ? { userId: session.user.id } : {}) },
  })
  return NextResponse.json({ ok: true })
}
