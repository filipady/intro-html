'use client'
import { useState, FormEvent } from 'react'
import { useRouter } from 'next/navigation'
import Link from 'next/link'

export default function RegisterPage() {
  const router = useRouter()
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')
  const [form, setForm] = useState({ name: '', email: '', password: '', confirm: '', firma: '', cui: '' })

  const set = (k: string) => (e: React.ChangeEvent<HTMLInputElement>) =>
    setForm(f => ({ ...f, [k]: e.target.value }))

  async function handleSubmit(e: FormEvent) {
    e.preventDefault()
    if (form.password !== form.confirm) { setError('Parolele nu coincid.'); return }
    if (form.password.length < 8) { setError('Parola trebuie să aibă minim 8 caractere.'); return }
    setLoading(true); setError('')

    const res = await fetch('/api/users/register', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ name: form.name, email: form.email, password: form.password, firma: form.firma, cui: form.cui }),
    })

    const data = await res.json()
    if (!res.ok) { setError(data.error || 'Eroare la înregistrare'); setLoading(false); return }
    router.push('/login?registered=1')
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-green-800 via-green-700 to-emerald-600 flex items-center justify-center p-4">
      <div className="w-full max-w-lg">
        <div className="text-center mb-8">
          <div className="text-5xl mb-3">🌿</div>
          <h1 className="text-3xl font-bold text-white">Gestiune Mediu</h1>
          <p className="text-green-200 mt-1">Creează un cont nou</p>
        </div>
        <div className="bg-white rounded-2xl shadow-2xl p-8">
          <h2 className="text-xl font-bold text-gray-800 mb-5">Înregistrare</h2>
          {error && <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-lg mb-4 text-sm">⚠️ {error}</div>}
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div><label className="label">Nume complet *</label><input className="input-field" value={form.name} onChange={set('name')} placeholder="Ion Popescu" required /></div>
              <div><label className="label">Email *</label><input type="email" className="input-field" value={form.email} onChange={set('email')} placeholder="ion@firma.ro" required /></div>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div><label className="label">Firma</label><input className="input-field" value={form.firma} onChange={set('firma')} placeholder="SC Firma SRL" /></div>
              <div><label className="label">CUI</label><input className="input-field" value={form.cui} onChange={set('cui')} placeholder="12345678" /></div>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div><label className="label">Parolă *</label><input type="password" className="input-field" value={form.password} onChange={set('password')} placeholder="Min. 8 caractere" required /></div>
              <div><label className="label">Confirmă parola *</label><input type="password" className="input-field" value={form.confirm} onChange={set('confirm')} placeholder="Repetă parola" required /></div>
            </div>
            <button type="submit" disabled={loading} className="w-full bg-green-600 hover:bg-green-700 disabled:opacity-60 text-white font-semibold py-3 rounded-lg transition-colors">
              {loading ? '⏳ Se creează...' : '✅ Creează cont'}
            </button>
          </form>
          <p className="text-sm text-gray-500 text-center mt-4">
            Ai deja cont? <Link href="/login" className="text-green-600 font-medium hover:underline">Intră în cont</Link>
          </p>
        </div>
      </div>
    </div>
  )
}
