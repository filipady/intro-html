import { prisma } from './prisma'
import { sendTermenNotificare } from './email'
import { differenceInDays } from 'date-fns'

export async function checkAndSendNotificari() {
  const azi = new Date()
  azi.setHours(0, 0, 0, 0)

  // Get all active termene that need notification
  const termene = await prisma.termen.findMany({
    where: {
      status: { in: ['ACTIV', 'DEPASIT'] },
    },
    include: {
      user: { select: { email: true, name: true, emailNotif: true } },
    },
  })

  // Group by user
  const byUser: Record<string, typeof termene> = {}
  for (const t of termene) {
    if (!t.user.emailNotif) continue
    const dataScadenta = new Date(t.dataScadenta)
    dataScadenta.setHours(0, 0, 0, 0)
    const zile = differenceInDays(dataScadenta, azi)

    let shouldNotify = false
    let notifField: 'notificat3zile' | 'notificat1zi' | 'notificatAzi' | null = null

    if (zile <= 0 && !t.notificatAzi) {
      shouldNotify = true
      notifField = 'notificatAzi'
    } else if (zile === 1 && !t.notificat1zi) {
      shouldNotify = true
      notifField = 'notificat1zi'
    } else if (zile <= 3 && zile > 1 && !t.notificat3zile) {
      shouldNotify = true
      notifField = 'notificat3zile'
    }

    if (shouldNotify && notifField) {
      if (!byUser[t.userId]) byUser[t.userId] = []
      byUser[t.userId].push(t)
      // Mark as notified
      await prisma.termen.update({
        where: { id: t.id },
        data: { [notifField]: true },
      })
    }
  }

  // Send grouped emails
  let emailsTrimise = 0
  for (const [userId, userTermene] of Object.entries(byUser)) {
    const user = userTermene[0].user
    const termeneForEmail = userTermene.map(t => {
      const dataScadenta = new Date(t.dataScadenta)
      dataScadenta.setHours(0, 0, 0, 0)
      return {
        titlu: t.titlu,
        dataScadenta: t.dataScadenta,
        tip: t.tip,
        prioritate: t.prioritate,
        zileRamase: differenceInDays(dataScadenta, azi),
      }
    })

    try {
      await sendTermenNotificare(user.email, user.name, termeneForEmail)
      
      // Log notifications
      for (const t of userTermene) {
        await prisma.notificareLog.create({
          data: {
            userId,
            terminId: t.id,
            tip: 'EMAIL_TERMEN',
            emailDest: user.email,
          },
        })
      }
      emailsTrimise++
    } catch (err) {
      console.error(`Eroare trimitere email catre ${user.email}:`, err)
    }
  }

  return { verificate: termene.length, emailsTrimise }
}
