import nodemailer from 'nodemailer'

const transporter = nodemailer.createTransport({
  host: process.env.SMTP_HOST,
  port: Number(process.env.SMTP_PORT) || 587,
  secure: false,
  auth: {
    user: process.env.SMTP_USER,
    pass: process.env.SMTP_PASS,
  },
})

interface TermenNotif {
  titlu: string
  dataScadenta: Date
  tip: string
  prioritate: string
  zileRamase: number
}

function culoarePrioritate(p: string) {
  const map: Record<string, string> = {
    CRITICA: '#dc2626',
    RIDICATA: '#ea580c',
    MEDIE: '#ca8a04',
    SCAZUTA: '#16a34a',
  }
  return map[p] || '#6b7280'
}

function labelZile(z: number) {
  if (z <= 0) return '⚠️ TERMEN DEPĂȘIT'
  if (z === 1) return 'Mâine'
  return `Peste ${z} zile`
}

export async function sendTermenNotificare(
  email: string,
  userName: string,
  termene: TermenNotif[]
) {
  const html = `
<!DOCTYPE html>
<html lang="ro">
<head><meta charset="UTF-8"><title>Termene Scadente</title></head>
<body style="margin:0;padding:0;background:#f3f4f6;font-family:Arial,sans-serif;">
  <table width="100%" cellpadding="0" cellspacing="0" style="background:#f3f4f6;padding:32px 0;">
    <tr><td align="center">
      <table width="600" cellpadding="0" cellspacing="0" style="background:#ffffff;border-radius:12px;overflow:hidden;box-shadow:0 4px 6px rgba(0,0,0,0.07);">
        
        <!-- Header -->
        <tr>
          <td style="background:linear-gradient(135deg,#15803d,#16a34a);padding:32px;text-align:center;">
            <div style="font-size:36px;margin-bottom:8px;">🌿</div>
            <h1 style="color:#fff;margin:0;font-size:24px;">Gestiune Mediu</h1>
            <p style="color:#bbf7d0;margin:8px 0 0;">Notificare termene scadente</p>
          </td>
        </tr>

        <!-- Salut -->
        <tr>
          <td style="padding:32px 32px 16px;">
            <p style="font-size:16px;color:#374151;margin:0;">Bună ziua, <strong>${userName}</strong>,</p>
            <p style="color:#6b7280;margin:12px 0 0;">Ai <strong>${termene.length} termen${termene.length > 1 ? 'e' : ''} important${termene.length > 1 ? 'e' : ''}</strong> care necesită atenție:</p>
          </td>
        </tr>

        <!-- Termene -->
        ${termene.map(t => `
        <tr>
          <td style="padding:8px 32px;">
            <div style="border:1px solid #e5e7eb;border-left:4px solid ${culoarePrioritate(t.prioritate)};border-radius:8px;padding:16px;">
              <div style="display:flex;justify-content:space-between;align-items:start;">
                <div>
                  <p style="font-weight:bold;color:#111827;margin:0 0 4px;">${t.titlu}</p>
                  <p style="color:#6b7280;font-size:13px;margin:0;">📋 ${t.tip.replace(/_/g,' ')} &nbsp;|&nbsp; 📅 ${new Date(t.dataScadenta).toLocaleDateString('ro-RO',{day:'2-digit',month:'long',year:'numeric'})}</p>
                </div>
                <span style="background:${culoarePrioritate(t.prioritate)};color:#fff;padding:4px 10px;border-radius:20px;font-size:12px;font-weight:bold;white-space:nowrap;margin-left:12px;">
                  ${labelZile(t.zileRamase)}
                </span>
              </div>
            </div>
          </td>
        </tr>
        `).join('')}

        <!-- CTA -->
        <tr>
          <td style="padding:24px 32px 32px;text-align:center;">
            <a href="${process.env.APP_URL}/termene" 
               style="background:#16a34a;color:#fff;padding:14px 32px;border-radius:8px;text-decoration:none;font-weight:bold;font-size:15px;display:inline-block;">
              📅 Vizualizează Calendar Termene
            </a>
            <p style="color:#9ca3af;font-size:12px;margin:20px 0 0;">
              Ai primit acest email deoarece ai notificările activate în contul tău.<br>
              <a href="${process.env.APP_URL}/setari" style="color:#16a34a;">Modifică preferințele de notificare</a>
            </p>
          </td>
        </tr>

        <!-- Footer -->
        <tr>
          <td style="background:#f9fafb;padding:16px 32px;text-align:center;border-top:1px solid #e5e7eb;">
            <p style="color:#9ca3af;font-size:11px;margin:0;">
              © ${new Date().getFullYear()} Gestiune Mediu · ${process.env.APP_URL}
            </p>
          </td>
        </tr>

      </table>
    </td></tr>
  </table>
</body>
</html>`

  await transporter.sendMail({
    from: process.env.EMAIL_FROM || 'Gestiune Mediu <noreply@gestiunemediu.ro>',
    to: email,
    subject: `🌿 ${termene.length} termen${termene.length > 1 ? 'e' : ''} scadent${termene.length > 1 ? 'e' : ''} - Gestiune Mediu`,
    html,
  })
}

export async function sendWelcomeEmail(email: string, name: string, password: string) {
  const html = `
<!DOCTYPE html>
<html lang="ro">
<body style="font-family:Arial,sans-serif;background:#f3f4f6;padding:32px;">
  <div style="max-width:500px;margin:0 auto;background:#fff;border-radius:12px;overflow:hidden;">
    <div style="background:linear-gradient(135deg,#15803d,#16a34a);padding:32px;text-align:center;">
      <div style="font-size:40px;">🌿</div>
      <h1 style="color:#fff;margin:8px 0 0;">Bun venit!</h1>
    </div>
    <div style="padding:32px;">
      <p>Salut <strong>${name}</strong>,</p>
      <p>Contul tău pe platforma <strong>Gestiune Mediu</strong> a fost creat cu succes.</p>
      <div style="background:#f0fdf4;border:1px solid #bbf7d0;border-radius:8px;padding:16px;margin:20px 0;">
        <p style="margin:0;"><strong>📧 Email:</strong> ${email}</p>
        <p style="margin:8px 0 0;"><strong>🔑 Parolă temporară:</strong> <code style="background:#e5e7eb;padding:2px 6px;border-radius:4px;">${password}</code></p>
      </div>
      <p style="color:#6b7280;font-size:13px;">Schimbă parola după primul login din Setări.</p>
      <div style="text-align:center;margin-top:24px;">
        <a href="${process.env.APP_URL}/login" style="background:#16a34a;color:#fff;padding:12px 28px;border-radius:8px;text-decoration:none;font-weight:bold;">
          Intră în platformă
        </a>
      </div>
    </div>
  </div>
</body>
</html>`

  await transporter.sendMail({
    from: process.env.EMAIL_FROM,
    to: email,
    subject: '🌿 Cont creat - Gestiune Mediu',
    html,
  })
}
