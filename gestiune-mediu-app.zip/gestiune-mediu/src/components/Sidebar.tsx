'use client'
import Link from 'next/link'
import { usePathname } from 'next/navigation'
import { useSession, signOut } from 'next-auth/react'

const navItems = [
  { href: '/dashboard', label: 'Dashboard', icon: '📊' },
  { href: '/calendar', label: 'Calendar Termene', icon: '📅' },
  { href: '/declaratii', label: 'Declarații', icon: '📄' },
  { href: '/termene', label: 'Termene', icon: '⏰' },
  { href: '/rapoarte', label: 'Rapoarte', icon: '📈' },
  { href: '/setari', label: 'Setări', icon: '⚙️' },
]

const adminItems = [
  { href: '/admin/users', label: 'Utilizatori', icon: '👥' },
]

export default function Sidebar() {
  const pathname = usePathname()
  const { data: session } = useSession()

  const isActive = (href: string) => pathname === href || pathname.startsWith(href + '/')

  return (
    <aside className="w-64 min-h-screen bg-white border-r border-gray-200 flex flex-col">
      {/* Logo */}
      <div className="p-6 border-b border-gray-100">
        <Link href="/dashboard" className="flex items-center gap-3">
          <span className="text-3xl">🌿</span>
          <div>
            <p className="font-bold text-gray-900 text-sm leading-tight">Gestiune Mediu</p>
            <p className="text-xs text-gray-500 truncate max-w-[140px]">{session?.user?.firma || 'Platform'}</p>
          </div>
        </Link>
      </div>

      {/* Nav */}
      <nav className="flex-1 p-4 space-y-1">
        {navItems.map(item => (
          <Link
            key={item.href}
            href={item.href}
            className={`flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-colors ${
              isActive(item.href)
                ? 'bg-green-50 text-green-700 border border-green-100'
                : 'text-gray-600 hover:bg-gray-50 hover:text-gray-900'
            }`}
          >
            <span className="text-base">{item.icon}</span>
            {item.label}
          </Link>
        ))}

        {session?.user?.role === 'ADMIN' && (
          <>
            <div className="pt-4 pb-1">
              <p className="text-xs font-semibold text-gray-400 uppercase tracking-wider px-3">Admin</p>
            </div>
            {adminItems.map(item => (
              <Link
                key={item.href}
                href={item.href}
                className={`flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-colors ${
                  isActive(item.href) ? 'bg-green-50 text-green-700' : 'text-gray-600 hover:bg-gray-50'
                }`}
              >
                <span>{item.icon}</span>
                {item.label}
              </Link>
            ))}
          </>
        )}
      </nav>

      {/* User */}
      <div className="p-4 border-t border-gray-100">
        <div className="flex items-center gap-3 mb-3">
          <div className="w-9 h-9 rounded-full bg-green-100 flex items-center justify-center text-green-700 font-bold text-sm">
            {session?.user?.name?.charAt(0).toUpperCase()}
          </div>
          <div className="flex-1 min-w-0">
            <p className="text-sm font-semibold text-gray-900 truncate">{session?.user?.name}</p>
            <p className="text-xs text-gray-500 truncate">{session?.user?.role}</p>
          </div>
        </div>
        <button
          onClick={() => signOut({ callbackUrl: '/login' })}
          className="w-full text-left text-sm text-red-500 hover:text-red-700 px-2 py-1.5 rounded hover:bg-red-50 transition-colors flex items-center gap-2"
        >
          <span>🚪</span> Deconectare
        </button>
      </div>
    </aside>
  )
}
