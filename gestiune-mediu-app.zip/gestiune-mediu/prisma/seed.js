// prisma/seed.js
const { PrismaClient } = require('@prisma/client');
const bcrypt = require('bcryptjs');

const prisma = new PrismaClient();

async function main() {
  console.log('🌱 Seeding database...');

  // Admin user
  const adminPass = await bcrypt.hash('Admin2024!', 12);
  const admin = await prisma.user.upsert({
    where: { email: 'admin@gestiunemediu.ro' },
    update: {},
    create: {
      email: 'admin@gestiunemediu.ro',
      name: 'Administrator',
      password: adminPass,
      role: 'ADMIN',
      firma: 'Filip Mixad SRL',
      cui: '44533293',
      telefon: '0744000000',
    },
  });

  // Demo user
  const userPass = await bcrypt.hash('User2024!', 12);
  const user1 = await prisma.user.upsert({
    where: { email: 'consultant@gestiunemediu.ro' },
    update: {},
    create: {
      email: 'consultant@gestiunemediu.ro',
      name: 'Ion Popescu',
      password: userPass,
      role: 'USER',
      firma: 'Econsulting SRL',
      cui: '12345678',
    },
  });

  // Declaratii demo
  const now = new Date();
  const dec1 = await prisma.declaratie.create({
    data: {
      tip: 'AUTORIZATIE_MEDIU',
      titlu: 'Autorizatie de Mediu - Hala Productie',
      descriere: 'Autorizatie de mediu pentru activitate productie plastic',
      status: 'APROBAT',
      dataEmitere: new Date(now.getFullYear() - 1, 2, 15),
      dataExpirare: new Date(now.getFullYear() + 4, 2, 14),
      numarDoc: 'AM-2023-0142',
      autoritate: 'APM Dambovita',
      judet: 'Dambovita',
      userId: admin.id,
    },
  });

  const dec2 = await prisma.declaratie.create({
    data: {
      tip: 'DECLARATIE_AFM',
      titlu: 'Declaratie taxa mediu 2024',
      descriere: 'Declaratie anuala taxa pentru fondul de mediu',
      status: 'IN_LUCRU',
      dataEmitere: new Date(now.getFullYear(), 0, 1),
      dataExpirare: new Date(now.getFullYear(), 3, 25),
      numarDoc: null,
      autoritate: 'AFM',
      judet: 'Dambovita',
      userId: admin.id,
    },
  });

  // Termene demo
  const zileTermene = [
    { zile: 5, tip: 'DEPUNERE_DECLARATIE', titlu: 'Depunere declaratie AFM - URGENT', prioritate: 'CRITICA' },
    { zile: 15, tip: 'RAPORTARE_LUNARA', titlu: 'Raportare lunara deseuri', prioritate: 'RIDICATA' },
    { zile: 25, tip: 'PLATA_TAXA', titlu: 'Plata taxa fond mediu', prioritate: 'MEDIE' },
    { zile: 45, tip: 'RAPORTARE_TRIMESTRIALA', titlu: 'Raportare trimestriala Q1 2024', prioritate: 'RIDICATA' },
    { zile: 60, tip: 'CONTROL_PLANIFICAT', titlu: 'Control planificat APM Dambovita', prioritate: 'MEDIE' },
    { zile: 90, tip: 'REINNOIRE_AUTORIZATIE', titlu: 'Reinnoire autorizatie de mediu', prioritate: 'RIDICATA' },
    { zile: 120, tip: 'RAPORTARE_ANUALA', titlu: 'Raportare anuala emisii', prioritate: 'MEDIE' },
    { zile: -5, tip: 'PLATA_TAXA', titlu: 'Plata taxa APM - DEPASIT', prioritate: 'CRITICA' },
  ];

  for (const t of zileTermene) {
    const data = new Date();
    data.setDate(data.getDate() + t.zile);
    await prisma.termen.create({
      data: {
        titlu: t.titlu,
        tip: t.tip,
        dataScadenta: data,
        prioritate: t.prioritate,
        status: t.zile < 0 ? 'DEPASIT' : 'ACTIV',
        declaratieId: t.tip === 'DEPUNERE_DECLARATIE' ? dec2.id : t.tip === 'REINNOIRE_AUTORIZATIE' ? dec1.id : null,
        userId: admin.id,
      },
    });
  }

  console.log('✅ Seed complet!');
  console.log('👤 Admin: admin@gestiunemediu.ro / Admin2024!');
  console.log('👤 User:  consultant@gestiunemediu.ro / User2024!');
}

main().catch(console.error).finally(() => prisma.$disconnect());
